webapp link: https://itraining-qoxyg.ondigitalocean.app/
github page: https://github.com/hugolardosa/iTrainingApp
microsite: https://ams20-301.github.io/
microsite documentation: https://ams20-301.github.io/documentacao.html

Sobre os testes de selenium:
O teste de registo na plataforma só pode ser corrido uma vez para correr novamente é necessario mudar o email de registo e no login, uma vez que só um email pode ser atribuido a uma conta 
